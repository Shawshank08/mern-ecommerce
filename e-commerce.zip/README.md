# E-Commerce

A full-stack e-commerce application built using:
- MongoDB
- Express.js
- React.js
- Node.js

This project is built step by step to demonstrate real world frontend and backend skills
